import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Clock, Users, CheckCircle2 } from "lucide-react";
import { Link } from "wouter";
import { Campaign } from "@/lib/mockData";

interface CampaignCardProps {
  campaign: Campaign;
}

export default function CampaignCard({ campaign }: CampaignCardProps) {
  const percentComplete = Math.min(100, Math.round((campaign.currentAmount / campaign.goalAmount) * 100));

  return (
    <Link href={`/campaigns/${campaign.id}`}>
      <a className="block h-full group">
        <Card className="h-full flex flex-col overflow-hidden border-border/60 bg-card hover:border-primary/30 hover:shadow-lg transition-all duration-300 group-hover:-translate-y-1">
          <div className="relative h-48 overflow-hidden">
            <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors z-10" />
            <img 
              src={campaign.imageUrl} 
              alt={campaign.title}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <Badge 
              className="absolute top-3 left-3 z-20 bg-background/90 text-foreground hover:bg-background font-medium shadow-sm backdrop-blur-sm"
            >
              {campaign.category}
            </Badge>
          </div>
          
          <CardHeader className="pb-3 pt-5 px-5">
            <div className="flex items-center gap-2 text-xs text-primary font-semibold mb-2 uppercase tracking-wider">
              <CheckCircle2 className="w-3 h-3" />
              Verified by {campaign.agencyName}
            </div>
            <h3 className="text-xl font-serif font-bold leading-tight text-foreground group-hover:text-primary transition-colors">
              {campaign.title}
            </h3>
            <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
              {campaign.description}
            </p>
          </CardHeader>

          <CardContent className="px-5 pb-3 flex-grow">
            <div className="space-y-2">
              <div className="flex justify-between text-sm font-medium">
                <span className="text-foreground">${campaign.currentAmount.toLocaleString()}</span>
                <span className="text-muted-foreground">of ${campaign.goalAmount.toLocaleString()}</span>
              </div>
              <Progress value={percentComplete} className="h-2 bg-muted/50" indicatorClassName="bg-primary" />
              <div className="flex justify-between text-xs text-muted-foreground pt-2">
                <div className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  <span>{campaign.supportersCount} supporters</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  <span>{campaign.daysLeft} days left</span>
                </div>
              </div>
            </div>
          </CardContent>

          <CardFooter className="px-5 pb-5 pt-0">
            <Button className="w-full bg-muted/50 text-foreground hover:bg-primary hover:text-white transition-all font-medium">
              View Campaign
            </Button>
          </CardFooter>
        </Card>
      </a>
    </Link>
  );
}
