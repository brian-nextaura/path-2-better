import { useRoute, Link } from "wouter";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent } from "@/components/ui/card";
import { MOCK_CAMPAIGNS } from "@/lib/mockData";
import { CheckCircle2, Share2, Shield, Clock, Users, AlertCircle } from "lucide-react";
import NotFound from "@/pages/not-found";

export default function CampaignDetail() {
  const [, params] = useRoute("/campaigns/:id");
  const id = params?.id;
  const campaign = MOCK_CAMPAIGNS.find((c) => c.id === id);

  if (!campaign) return <NotFound />;

  const percentComplete = Math.round((campaign.currentAmount / campaign.goalAmount) * 100);

  return (
    <div className="min-h-screen bg-background font-sans">
      <Navbar />
      
      <div className="container mx-auto px-4 md:px-6 py-8 md:py-12">
        {/* Breadcrumb */}
        <div className="mb-6 text-sm text-muted-foreground">
          <Link href="/campaigns"><a className="hover:text-primary">Campaigns</a></Link>
          <span className="mx-2">/</span>
          <span className="text-foreground font-medium">{campaign.title}</span>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 lg:gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Image */}
            <div className="rounded-2xl overflow-hidden shadow-md aspect-video relative bg-muted">
              <img 
                src={campaign.imageUrl} 
                alt={campaign.title} 
                className="w-full h-full object-cover"
              />
              <Badge className="absolute top-4 left-4 text-base px-3 py-1">
                {campaign.category}
              </Badge>
            </div>

            {/* Title & Verified Status */}
            <div>
              <h1 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4 leading-tight">
                {campaign.title}
              </h1>
              <div className="flex items-center gap-3 text-sm md:text-base bg-primary/5 p-3 rounded-lg border border-primary/10 inline-flex">
                <Shield className="w-5 h-5 text-primary fill-primary/20" />
                <span className="text-foreground">
                  Verified by <span className="font-semibold text-primary">{campaign.agencyName}</span>
                </span>
              </div>
            </div>

            {/* Description */}
            <div className="prose prose-lg prose-slate max-w-none">
              <h3 className="font-serif text-2xl font-bold text-foreground">About this pathway</h3>
              <p>
                {campaign.description}
              </p>
              <p>
                Support for {campaign.beneficiaryName} is managed directly by {campaign.agencyName}. 
                Funds are released only to verified vendors (landlords, schools, medical providers) 
                to ensure they are used exactly as intended.
              </p>
              <p>
                By contributing to this campaign, you are not just providing funds, but signaling to 
                {campaign.beneficiaryName} that their community believes in their future.
              </p>
            </div>

            {/* Milestones */}
            <div className="bg-card border border-border/60 rounded-xl p-6 md:p-8">
              <h3 className="font-serif text-2xl font-bold mb-6">Milestones</h3>
              <div className="space-y-6">
                {campaign.milestones.map((milestone, index) => (
                  <div key={index} className="relative pl-8 md:pl-10">
                    {/* Connector Line */}
                    {index !== campaign.milestones.length - 1 && (
                      <div className="absolute left-[11px] md:left-[15px] top-8 bottom-[-24px] w-0.5 bg-border" />
                    )}
                    
                    {/* Status Indicator */}
                    <div className={`absolute left-0 top-1 w-6 h-6 md:w-8 md:h-8 rounded-full flex items-center justify-center border-2 ${milestone.completed ? 'bg-primary border-primary text-white' : 'bg-background border-muted-foreground/30 text-muted-foreground'}`}>
                      {milestone.completed ? <CheckCircle2 className="w-4 h-4 md:w-5 md:h-5" /> : <div className="w-2 h-2 rounded-full bg-muted-foreground/30" />}
                    </div>

                    {/* Content */}
                    <div className={`${milestone.completed ? 'opacity-100' : 'opacity-70'}`}>
                      <div className="flex justify-between items-center mb-1">
                        <h4 className="font-bold text-lg">{milestone.title}</h4>
                        <span className="font-mono text-sm text-muted-foreground">${milestone.amount}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {milestone.completed ? "Funded & Verified" : "Pending Funding"}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar / Donation Card */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <Card className="border-border/60 shadow-lg">
                <CardContent className="p-6 space-y-6">
                  
                  {/* Progress Header */}
                  <div className="space-y-2">
                    <div className="flex items-baseline gap-2">
                      <span className="text-4xl font-bold font-serif text-primary">${campaign.currentAmount.toLocaleString()}</span>
                      <span className="text-muted-foreground">raised of ${campaign.goalAmount.toLocaleString()}</span>
                    </div>
                    <Progress value={percentComplete} className="h-3" />
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>{percentComplete}% funded</span>
                      <span>{campaign.supportersCount} supporters</span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="space-y-3">
                    <Button size="lg" className="w-full text-lg h-14 font-bold shadow-md hover:shadow-lg transition-all">
                      Donate Now
                    </Button>
                    <Button variant="outline" size="lg" className="w-full gap-2">
                      <Share2 className="w-4 h-4" /> Share Campaign
                    </Button>
                  </div>

                  <Separator />

                  {/* Trust Indicators */}
                  <div className="space-y-4 text-sm">
                    <div className="flex items-start gap-3">
                      <ShieldCheck className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold block text-foreground">Agency Managed</span>
                        <span className="text-muted-foreground">Funds are managed by {campaign.agencyName}, not given as cash.</span>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold block text-foreground">Transparency Guarantee</span>
                        <span className="text-muted-foreground">Receive updates when milestones are met and funds are spent.</span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Recent Donations Placeholder */}
                  <div className="bg-muted/30 rounded-lg p-4 mt-6">
                    <h4 className="font-bold text-sm mb-3 flex items-center gap-2">
                      <Users className="w-4 h-4" /> Recent Supporters
                    </h4>
                    <div className="space-y-3">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="flex items-center gap-3 text-sm">
                          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs">
                            {["JD", "AM", "RK"][i-1]}
                          </div>
                          <div>
                            <p className="font-medium">Anonymous</p>
                            <p className="text-xs text-muted-foreground">Donated ${[50, 100, 25][i-1]} • 2h ago</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
