import { User, Home, GraduationCap, HeartPulse, Briefcase } from "lucide-react";

// Import generated images
import heroImage from "@assets/generated_images/Community_support_in_park_ff7ec8ed.png";
import housingImage from "@assets/generated_images/Empty_sunny_apartment_49030cce.png";
import educationImage from "@assets/generated_images/Study_materials_on_table_a3761546.png";
import medicalImage from "@assets/generated_images/Medical_glasses_and_papers_7afb4b5c.png";

export const IMAGES = {
  hero: heroImage,
  housing: housingImage,
  education: educationImage,
  medical: medicalImage,
};

export interface Campaign {
  id: string;
  title: string;
  beneficiaryName: string;
  agencyName: string;
  agencyLogo?: string; // URL or placeholder
  description: string;
  goalAmount: number;
  currentAmount: number;
  category: "Housing" | "Education" | "Medical" | "Employment" | "Basic Needs";
  imageUrl: string;
  daysLeft: number;
  supportersCount: number;
  milestones: {
    title: string;
    amount: number;
    completed: boolean;
  }[];
}

export const CATEGORIES = [
  { name: "All", icon: null },
  { name: "Housing", icon: Home },
  { name: "Education", icon: GraduationCap },
  { name: "Medical", icon: HeartPulse },
  { name: "Employment", icon: Briefcase },
  { name: "Basic Needs", icon: User },
];

export const MOCK_CAMPAIGNS: Campaign[] = [
  {
    id: "1",
    title: "Secure First Month's Rent",
    beneficiaryName: "Sarah M.",
    agencyName: "Downtown Housing Outreach",
    description: "Help Sarah secure her first apartment after 6 months in a shelter. She has found employment and just needs the deposit to get the keys.",
    goalAmount: 1200,
    currentAmount: 850,
    category: "Housing",
    imageUrl: IMAGES.housing,
    daysLeft: 12,
    supportersCount: 24,
    milestones: [
      { title: "Application Fee", amount: 100, completed: true },
      { title: "Security Deposit", amount: 1100, completed: false },
    ]
  },
  {
    id: "2",
    title: "Trade School Tuition",
    beneficiaryName: "James R.",
    agencyName: "Pathways to Work",
    description: "James has been accepted into an HVAC certification program. This fund covers his first semester tuition and required tools.",
    goalAmount: 3500,
    currentAmount: 1200,
    category: "Education",
    imageUrl: IMAGES.education,
    daysLeft: 45,
    supportersCount: 18,
    milestones: [
      { title: "Enrollment Deposit", amount: 500, completed: true },
      { title: "Tools & Equipment", amount: 1000, completed: false },
      { title: "Tuition Balance", amount: 2000, completed: false },
    ]
  },
  {
    id: "3",
    title: "Dental Work for Job Interview",
    beneficiaryName: "Michael K.",
    agencyName: "Community Health Partners",
    description: "Michael needs urgent dental work to restore his confidence and health as he prepares for job interviews in the service industry.",
    goalAmount: 2100,
    currentAmount: 1950,
    category: "Medical",
    imageUrl: IMAGES.medical,
    daysLeft: 5,
    supportersCount: 42,
    milestones: [
      { title: "Initial Exam", amount: 150, completed: true },
      { title: "Treatment Plan", amount: 1950, completed: false },
    ]
  },
];
